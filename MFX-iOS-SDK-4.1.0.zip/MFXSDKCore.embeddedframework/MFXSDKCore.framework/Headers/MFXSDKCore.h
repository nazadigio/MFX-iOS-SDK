//
//  MFXSDKCore.h
//  MFXSDKCore
//
//  Created by ofirkariv on 23/04/2019.
//  Copyright © 2019 MobFox Mobile Advertising GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MobFoxSDK.h"
#import "MFXBannerAd.h"
//! Project version number for MFXSDKCore.
FOUNDATION_EXPORT double MFXSDKCoreVersionNumber;

//! Project version string for MFXSDKCore.
FOUNDATION_EXPORT const unsigned char MFXSDKCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MFXSDKCore/PublicHeader.h>


